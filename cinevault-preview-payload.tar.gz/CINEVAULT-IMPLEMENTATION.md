# FLIXTV webOS 0.28.0 preview payload

- UI: retained from the uploaded CineVault ZIP.
- Catalogue and metadata: TMDB API, through `/api/tmdb` in Railway Preview.
- Playback: BingeAPI iframe for movie and TV episode TMDB IDs.
- The original responsive app under `apps/web` is not changed.
- The local `keys.js` file is intentionally not included. On a physical TV build, copy `keys.example.js` to `keys.js` and add a TMDB v3 key. Railway Preview injects its own key-backed TMDB proxy.
